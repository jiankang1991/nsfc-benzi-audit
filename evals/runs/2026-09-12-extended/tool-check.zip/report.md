# 长稿、多文件与中断后复核：独立工具检查

结论：主流程可执行，且与核心判据、旧意见状态和报告模板的证据边界一致。实际完成两份自造 UTF-8 普通文本的索引、全段读取、跨文件定位、检查点、源文件修订、旧索引拒绝、重建索引和继续复核。发现一个局部导航缺陷 TC-01；未发现会阻止该主流程或要求错误扩张证据范围的正文冲突。

## 实测材料与结果

只读取指定的 after/nsfc-benzi-audit 目录内的 SKILL.md、scripts/review_index.py、references/long-draft-review.md、benzi-logic.md、audit-surfaces.md、research-claims.md 和 assets/report-template.md。没有读取其他仓库、测试或旧讨论，没有联网、委派或修改被查 skill。所有自造材料、脚本副本和结果均在 tool-check 下。

实际执行脚本为 [exercise.py](exercise.py)，每次工具调用的完整参数、退出码、stdout、stderr 见 [operations.json](operations.json)。本次脚本成功退出 0。脚本使用 300 字符目标块大小，以有限材料触发多块读取，不声称做过真实大部头材料或性能压测。

| 操作 | 输入/证据 | 实际结果 |
| --- | --- | --- |
| 两文件建立索引 | v1 正文115行、附录49行；文件名含中文和空格 | 2 个来源、15 个块；路径相对索引目录保存；每个来源的行范围无遗漏、无重叠 |
| 取段与定位 | [index-v1.json](run/review-work/index-v1.json)、[read-v1.txt](run/review-work/read-v1.txt) | 所有块实际取出并读到；表格的一个大块标为 oversized，表格和代码围栏未被从中切开；代码中伪标题未入标题表 |
| 跨文件反查 | 正文v1第7、11行与附录v1第7行 | Q2 的支撑在附录，旧意见 M01 应撤销，不能因为没有独立 T2 就要求新增任务 |
| 中断检查点 | [checkpoint-v1.md](run/review-work/checkpoint-v1.md) | 保留选定来源、已读范围、M01撤销依据、M02两端证据及下一步核验边界 |
| 修改来源后继续 | 两文件头部增加4行；附录设备可用时间从第6个月改为第2个月 | 旧索引 verify 和 read 均退出1，输出 `Source changed`，没有以旧行号取出新文本；沿用旧输出路径建索引也退出1 |
| 重建与重新定位 | [index-v2.json](run/review-work/index-v2.json)、[read-v2.txt](run/review-work/read-v2.txt) | 新索引校验成功、15块读取成功；特意颠倒来源参数顺序后 S01 从正文变为附录，证实不能把 chunk ID 当版本间身份 |
| 继续复核并出报告 | [复审报告-v2.md](run/review-work/复审报告-v2.md) | 保留 M01/M02；M02 的时间矛盾在文字上已解决，资源事实与许可原件仍未核验 |

v1 原文已保存在 [正文-v1.txt](run/snapshots/正文-v1.txt) 和 [附录-v1.txt](run/snapshots/附录-v1.txt)，工作来源当前为 v2。v1 索引指向现已变动的工作来源，因此现在再 verify 必然失败，这是本次预期结果。若要完整重跑，应将 exercise.py 复制到 tool-check 下一个新的空子目录后执行，避免覆盖本次证据。

## TC-01：首行分隔线被当作未闭合元数据，全文标题与块边界丢失

影响：低优先级、可复现的导航缺陷。原文没有丢失，仍能按行读完，也不影响哈希拒绝旧来源；但带这种开头的长稿会失去标题地图，全部合成一个 oversized 块，明显削弱工具宣称提供的长稿分段导航。问题位置为 scripts/review_index.py 第25行及第28—32行：只要首行是 `---` 就进入 frontmatter，后续没有闭合符时一直跳过标题和空行边界识别。

输入是 [horizontal-rule.txt](horizontal-rule.txt)：13行、102字符，首行是单独的 `---`，后面是普通正文与“正文／科学问题／验证与边界”三个 Markdown 标题，没有元数据块。对照 [with-frontmatter.txt](with-frontmatter.txt) 含真正闭合的 YAML 头部。

已执行的复现命令如下；再次执行时应使用尚不存在的输出文件名：

```bash
python3 /tmp/nsfc-long-claims-ysfwwer1/after/nsfc-benzi-audit/scripts/review_index.py build /tmp/nsfc-long-claims-ysfwwer1/tool-check/horizontal-rule.txt /tmp/nsfc-long-claims-ysfwwer1/tool-check/with-frontmatter.txt --output /tmp/nsfc-long-claims-ysfwwer1/tool-check/hr-index.json --max-chars 45
```

实际输出 [hr-index.json](hr-index.json) 中，第一个来源 `headings: []`，只有第1—13行的一个102字符块，`oversized: true`。该正文的三个短段本可正常分开。闭合元数据的对照来源则正确列出两个标题、三个块。

最小修正：在判定首行 `---` 为 frontmatter 前，先确认后续存在闭合 `---` 或 `...`；没有闭合符时按普通文本继续处理。将第25行替换为：

```python
frontmatter = bool(
    lines and lines[0].strip() == "---"
    and any(line.strip() in ("---", "...") for line in lines[1:])
)
```

没有修改被查脚本；仅在 tool-check 内生成 [review_index-minimal-proposal.py](review_index-minimal-proposal.py) 实测此最小提议。结果 [hr-index-proposal.json](hr-index-proposal.json) 正确恢复三个标题、三个块，闭合 YAML 对照来源的完整索引记录与修前完全相同，比较结果见 [minimal-proposal-check.json](minimal-proposal-check.json)。此提议只解决上述无闭合符的明确情形，不宣称实现完整 Markdown/YAML 解析。

## 文档与判据、报告衔接

未发现本次范围内需修改的规范冲突。long-draft-review 第17、30、34行分别限制块编号的快照效力、索引与语义覆盖的区别、变更后的重新核验；与核心 COV/EVD 的全来源反查、缺失附件不等于缺陷一致。第38—42行要求精确来源、最小修改、复用编号和如实披露未检查内容，报告模板的“旧意见复核”和“核查覆盖与限制”也能表达这些状态。

实测中的 M02 可给出可执行的最小意见：把使用时间改到可用时间之后，或在确有事实时订正资源时间；没有要求无条件扩充任务。后续作者只修正文案时，SKILL.md 第4节与核心 EVD 允许报告“方案文字已解决，同时实际事实未核验”，无需误写为许可已经核实。M01 则可按同一编号撤销，附录和覆盖记录引用该编号，不重复生成问题。

限制：未检查 PDF/DOCX 提取、原图、外部事实和官方要求，也未审计其他学科专项。本次仅有一次模拟中断检查点，没有宣称验证任何持久会话系统；语义复核结论来自本次实际阅读，脚本断言只证明取段与索引行为。
