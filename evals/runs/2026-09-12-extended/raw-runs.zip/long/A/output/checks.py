"""Recompute only quantities explicitly provided in input/application.md."""

import itertools
import json
from fractions import Fraction
from pathlib import Path


def check_schedule(durations, releases, assignments, starts, machines):
    assert len(durations) == len(releases) == len(assignments) == len(starts)
    ends = [s + p for s, p in zip(starts, durations)]
    for j in range(len(durations)):
        assert 0 <= assignments[j] < machines
        assert starts[j] >= releases[j]
        for k in range(j):
            if assignments[j] == assignments[k]:
                assert ends[j] <= starts[k] or ends[k] <= starts[j]
    return max(ends)


r1 = check_schedule([1] * 8, [0] * 8, [0, 1] * 4,
                    [0, 0, 1, 1, 2, 2, 3, 3], 2)
r2 = check_schedule([1] * 8, [0] * 4 + [5] * 4, [0, 1] * 4,
                    [0, 0, 1, 1, 5, 5, 6, 6], 2)
assert r1 == 8 // 2 == 4
assert r2 == 5 + 4 // 2 == 7

durations = [3, 3, 2, 2, 2]
loads = [0, 0]
trace = []
for j in sorted(range(5), key=lambda i: (-durations[i], i)):
    machine = min(range(2), key=lambda i: (loads[i], i))
    start = loads[machine]
    loads[machine] += durations[j]
    trace.append([j + 1, machine + 1, start, loads[machine]])
assert max(loads) == 7
best = min(max(sum(p for p, a in zip(durations, assignment) if a == 0),
               sum(p for p, a in zip(durations, assignment) if a == 1))
           for assignment in itertools.product(range(2), repeat=5))
candidate = check_schedule(durations, [0] * 5, [0, 0, 1, 1, 1],
                           [0, 3, 0, 2, 4], 2)
assert candidate == best == sum(durations) // 2 == 6

theta = (Fraction(2) + Fraction(8)) / 2
pooled = Fraction(9 * 2 + 8, 9 + 1)
assert theta == 5 and pooled == Fraction(13, 5)

runs, duration, slots, window = 6 * 4 * 5, 12, 4, 240
required = runs * duration
available = slots * window
capacity = slots * (window // duration)
minimum_window = ((runs + slots - 1) // slots) * duration
assert (required, available, capacity, minimum_window) == (1440, 960, 80, 360)
assert (10 + 12 * 8) * 4 == 424 < 8 * 60

result = {
    "purpose": "Independent arithmetic and supplied-example checks, not execution of applicant software",
    "F01": {"shared_H_input": [8, 1, 2], "R01_lower_bound_and_feasible": r1,
            "R02_late_jobs_lower_bound_and_feasible": r2},
    "F02": {"D04_recreated_trace_job_machine_start_end": trace,
            "D04_C": max(loads), "assignment_count": 32,
            "enumerated_optimum": best, "feasible_C_equals_workload_lower_bound": candidate},
    "F03": {"defined_theta_seconds": str(theta), "pooled_seconds": str(pooled),
            "signed_difference_seconds": str(pooled - theta)},
    "F04": {"runs": runs, "required_slot_minutes": required,
            "available_slot_minutes": available, "max_runs_in_window": capacity,
            "missing_runs": runs - capacity, "minimum_window_minutes_excluding_freeze": minimum_window},
    "retained_replay_bound_seconds": 424,
    "all_assertions_passed": True,
}
output_path = Path(__file__).with_name("checks.json")
output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, ensure_ascii=False, indent=2))
